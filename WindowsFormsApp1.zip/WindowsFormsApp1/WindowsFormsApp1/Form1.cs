﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // Привязываем обработчики событий
            button1.Click += new EventHandler(button1_Click);
            button2.Click += new EventHandler(button2_Click);

            radioButton1.Checked = true;
        }

        // линейный алгоритм
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                double x = Convert.ToDouble(textBox1.Text);
                double y = Convert.ToDouble(textBox2.Text);
                double z = Convert.ToDouble(textBox3.Text);

                // Вычисляем первую часть: |cos x - cos y|^(1+2sin²y)
                double cosDiff = Math.Abs(Math.Cos(x) - Math.Cos(y));
                double exponent = 1 + 2 * Math.Pow(Math.Sin(y), 2);
                double part1 = Math.Pow(cosDiff, exponent);

                // Вычисляем вторую часть: (1 + z + z²/2 + z³/3 + z⁴/4)
                double part2 = 1 + z + (Math.Pow(z, 2) / 2) + (Math.Pow(z, 3) / 3) + (Math.Pow(z, 4) / 4);

                double result = part1 * part2;

                label4.Text = $"W = {result:F6}";
            }
            catch (FormatException)
            {
                label4.Text = "Ошибка: введите числа!";
            }
            catch (Exception ex)
            {
                label4.Text = $"Ошибка: {ex.Message}";
            }
        }

        // разветвляющийся алгоритм
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                double x = Convert.ToDouble(textBox4.Text);
                double y = Convert.ToDouble(textBox5.Text);

                // функция
                double f_x = 0;
                if (radioButton1.Checked) // cos(x)
                {
                    f_x = Math.Cos(x);
                }
                else if (radioButton2.Checked) // sqr(x) 
                {
                    f_x = Math.Pow(x, 2);
                }
                else if (radioButton3.Checked) // exp(x)
                {
                    f_x = Math.Exp(x);
                }
                else
                {
                    label7.Text = "Выберите функцию!";
                    return;
                }

                double result = 0;

                // проверка деления на 0
                if (y == 0)
                {
                    label7.Text = "Ошибка: Y не может быть 0!";
                    return;
                }

                double ratio = x / y;

                // Разветвление по условиям
                if (ratio > 0)
                {
                    result = Math.Log(y + 2) + f_x;
                }
                else if (ratio < 0)
                {
                    result = Math.Log(Math.Abs(y)) - Math.Tan(f_x);
                }
                else // x/y = 0 (когда x=0)
                {
                    result = f_x * Math.Pow(y, 3);
                }

                // резы
                label7.Text = $"a = {result:F6}";

                // красный
                if (checkBox1.Checked)
                {
                    label7.ForeColor = System.Drawing.Color.Red;
                }
                else
                {
                    label7.ForeColor = System.Drawing.Color.Black;
                }
            }
            catch (FormatException)
            {
                label7.Text = "Ошибка: введите числа!";
                label7.ForeColor = System.Drawing.Color.Black;
            }
            catch (Exception ex)
            {
                label7.Text = $"Ошибка: {ex.Message}";
                label7.ForeColor = System.Drawing.Color.Black;
            }
        }

        // обработчик событий
        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
        }

        private void label5_Click(object sender, EventArgs e)
        {
        }

        private void label5_Click_1(object sender, EventArgs e)
        {
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
        }
    }
}